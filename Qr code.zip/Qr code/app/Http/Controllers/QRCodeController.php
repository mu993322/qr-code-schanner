namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\QRCode;
use Illuminate\Support\Facades\Auth;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class QRCodeController extends Controller
{
    public function generate(Request $request) {
        $request->validate([
            'url' => 'required|url',
        ]);

        $qrCode = new QRCode();
        $qrCode->user_id = Auth::id();
        $qrCode->url = $request->url;
        $qrCode->qr_code = QrCode::format('png')->size(200)->generate($request->url);
        $qrCode->save();

        return response()->json(['qr_code' => $qrCode->qr_code]);
    }

    public function show($id, Request $request) {
        $qrCode = QRCode::findOrFail($id);
        $qrCode->scans()->create([
            'ip' => $request->ip(),
            'device' => $request->header('User-Agent'),
        ]);

        return response()->json(['url' => $qrCode->url]);
    }
}
