use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\QRCodeController;

// Authentication Routes
Route::post('/register', [AuthController::class, 'register']);
Route::get('/verify/{token}', [AuthController::class, 'verifyEmail']);

// QR Code Routes
Route::middleware('auth')->group(function () {
    Route::post('/generate', [QRCodeController::class, 'generate']);
    Route::get('/qr/{id}', [QRCodeController::class, 'show']);
});
