<!DOCTYPE html>
<html>
<head>
    <title>QR Code Generator</title>
</head>
<body>
    <h2>Generate QR Code</h2>
    <form action="/generate" method="POST">
        @csrf
        <input type="text" name="url" placeholder="Enter URL" required>
        <button type="submit">Generate</button>
    </form>

    @if(session('qr_code'))
        <h3>Generated QR Code:</h3>
        <img src="data:image/png;base64,{{ base64_encode(session('qr_code')) }}" />
    @endif
</body>
</html>
